import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class product {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/jdbc";
        String username = "root";
        String userpassword = "12345";
        try (Connection connection = DriverManager.getConnection(url, username, userpassword)) {
            System.out.println("Connect Success");
            String querysql = "SELECT id, name, price_per_unit, active_for_sell FROM product";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(querysql);
            printResults(resultSet);
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void printResults(ResultSet resultSet) throws SQLException {
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");
            float price_per_unit = resultSet.getFloat("price_per_unit");
            boolean active_for_sell = resultSet.getBoolean("active_for_sell");

            System.out.println("id: " + id);
            System.out.println("name: " + name);
            System.out.println("price_per_unit: " + price_per_unit);
            System.out.println("active_for_sell: " + active_for_sell);
            System.out.println();
        }
    }
}
